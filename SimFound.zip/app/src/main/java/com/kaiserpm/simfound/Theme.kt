package com.kaiserpm.simfound

import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable

/** Единый стиль: фиолетовая тема, моноширинный шрифт. */
object Th {
    val TEXT = 0xFFEDE9FE.toInt()
    val MUTED = 0xFFA79BCB.toInt()
    val ACCENT = 0xFF9B4DFF.toInt()
    val ACCENT_DARK = 0xFF7C3AED.toInt()
    val PINK = 0xFFD946EF.toInt()
    val GLASS = 0xCC1B1633.toInt()
    val GLASS_BTN = 0xCC2B2447.toInt()
    val SCRIM = 0xCC0E0B1A.toInt()

    fun mono(bold: Boolean = false): Typeface = Typeface.create(Typeface.MONOSPACE, if (bold) Typeface.BOLD else Typeface.NORMAL)

    fun dp(ctx: Context, v: Float) = (v * ctx.resources.displayMetrics.density).toInt()

    /** Залитая кнопка с фиолетовым градиентом. */
    fun filled(ctx: Context, radiusDp: Float): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xFFA25BFF.toInt(), ACCENT_DARK)).apply {
            cornerRadius = dp(ctx, radiusDp).toFloat()
        }

    /** Тёмное «стекло» с тонкой обводкой. */
    fun glass(ctx: Context, radiusDp: Float, color: Int = GLASS_BTN, strokeColor: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            cornerRadius = dp(ctx, radiusDp).toFloat()
            setColor(color)
            if (strokeColor != 0) setStroke(dp(ctx, 1.5f), strokeColor)
        }
}
