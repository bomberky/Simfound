package com.kaiserpm.simfound

import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock

/** Непрерывно читает кадры экрана и определяет, какое окно игры сейчас показано. */
class Capture(private val mp: MediaProjection, w: Int, h: Int, dpi: Int) {
    private val thread = HandlerThread("cap").apply { start() }
    private val handler = Handler(thread.looper)
    private val reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
    private var vd: VirtualDisplay? = null
    private var first = true

    init {
        try {
            mp.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { Bot.capStatus = "остановлена системой" }
            }, handler)
            vd = mp.createVirtualDisplay("sf", w, h, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.surface, null, handler)
            Bot.capStatus = "запущена, кадров пока нет"
            reader.setOnImageAvailableListener({ r ->
                val img = try { r.acquireLatestImage() } catch (e: Exception) { null }
                if (img != null) {
                    try {
                        onFrame(img)
                    } catch (e: Throwable) {
                        Bot.capStatus = "ошибка кадра: ${e.javaClass.simpleName}"
                    } finally { img.close() }
                }
            }, handler)
        } catch (e: Throwable) {
            Bot.capStatus = "ошибка запуска: ${e.javaClass.simpleName} ${e.message}"
        }
    }

    private fun rgb(img: Image, x: Int, y: Int): Int {
        val pl = img.planes[0]
        val o = y * pl.rowStride + x * pl.pixelStride
        val b = pl.buffer
        return ((b.get(o).toInt() and 0xFF) shl 16) or ((b.get(o + 1).toInt() and 0xFF) shl 8) or (b.get(o + 2).toInt() and 0xFF)
    }

    private fun onFrame(img: Image) {
        Bot.state = Bot.classifyPix(img.width, img.height) { x, y -> rgb(img, x, y) }
        val c = rgb(img, img.width / 2, img.height / 2)
        Bot.cap = "${img.width}x${img.height} центр=${(c shr 16) and 255},${(c shr 8) and 255},${c and 255}"
        Bot.capTs = SystemClock.uptimeMillis()
        if (first) { first = false; Bot.capStatus = "кадры идут" }
    }

    fun release() {
        try { vd?.release() } catch (e: Exception) {}
        try { reader.close() } catch (e: Exception) {}
        try { mp.stop() } catch (e: Exception) {}
        thread.quitSafely()
    }
}
