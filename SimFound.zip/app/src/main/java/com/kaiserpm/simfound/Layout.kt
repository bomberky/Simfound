package com.kaiserpm.simfound

/**
 * Координаты и цвета-маркеры окон игры в долях экрана (0..1), сняты со скриншотов 2340x1080.
 * Если игра сдвинет интерфейс — правится только этот файл.
 */
object L {
    // маркер: x, y, r, g, b
    val NOFUNDS = listOf(      // «Недостаточно средств» (розовая кнопка «Испытайте удачу»)
        floatArrayOf(0.342f, 0.722f, 202f, 113f, 255f),
        floatArrayOf(0.470f, 0.782f, 202f, 113f, 255f))
    val CONFIRM_NUM = listOf(  // «Подтверждение… приобрести номер» (жёлтая «Покупка»)
        floatArrayOf(0.3996f, 0.583f, 253f, 206f, 58f),
        floatArrayOf(0.487f, 0.643f, 247f, 200f, 52f))
    val INPUT = listOf(        // «Покупка телефонного номера» (жёлтая «Продолжить»)
        floatArrayOf(0.3825f, 0.727f, 252f, 205f, 57f),
        floatArrayOf(0.5043f, 0.782f, 247f, 200f, 52f))
    val CONFIRM_SVC = listOf(  // «ПОДТВЕРЖДЕНИЕ ПОКУПКИ» (жёлтая кнопка 200 GC)
        floatArrayOf(0.502f, 0.792f, 249f, 204f, 43f),
        floatArrayOf(0.632f, 0.847f, 249f, 204f, 43f))

    val BUSY = listOf(         // красная плашка «Введенный Вами номер уже используется»: красный значок и край
        floatArrayOf(0.3453f, 0.937f),
        floatArrayOf(0.3496f, 0.9463f),
        floatArrayOf(0.6658f, 0.9259f))

    // точки нажатия
    val PHONE_ROW = floatArrayOf(0.616f, 0.659f)   // кнопка «200 GC» напротив «Номер телефона» во вкладке «Услуги»
    val SVC_BUY = floatArrayOf(0.567f, 0.819f)     // жёлтая «200 GC» в подтверждении покупки
    val FIELD = floatArrayOf(0.500f, 0.641f)       // поле «Нажмите для ввода…»
    val CONT = floatArrayOf(0.444f, 0.755f)        // «Продолжить»
    val NUM_BUY = floatArrayOf(0.444f, 0.614f)     // «Покупка»
    val NUM_CANCEL = floatArrayOf(0.558f, 0.614f)  // «Отмена»
    val SVC_CLOSE = floatArrayOf(0.692f, 0.154f)   // крестик в «ПОДТВЕРЖДЕНИЕ ПОКУПКИ»
    val CLOSE = floatArrayOf(0.721f, 0.220f)       // крестик «Недостаточно средств»

    const val FOCUS_DELAY = 90L  // пауза после нажатия на поле, пока оно получит фокус (мс)
    const val TYPE_DELAY = 180L  // пауза после ввода номера перед «Продолжить» (мс)
    const val REOPEN_1 = 350L    // после закрытия «Недостаточно средств» (мс)
    const val REOPEN_2 = 330L    // после нажатия «200 GC» у номера телефона (мс)
    const val REOPEN_3 = 380L    // после нажатия «200 GC» в подтверждении (мс)
    const val WAIT_NUM = 700L    // сколько ждать окно «Подтверждение», иначе номер занят (мс)
}
