package com.kaiserpm.simfound

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

class FloatingService : Service() {
    private lateinit var wm: WindowManager
    private val ui = Handler(Looper.getMainLooper())
    private var panel: View? = null
    private var icon: TextView? = null
    private var result: View? = null
    private var statusTv: TextView? = null
    private var capture: Capture? = null
    private lateinit var plp: WindowManager.LayoutParams
    private lateinit var ilp: WindowManager.LayoutParams
    private var panelOn = false
    private var iconOn = false

    override fun onBind(i: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    private fun readData(i: Intent): Intent? =
        if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra("data", Intent::class.java)
        else i.getParcelableExtra<Intent>("data")

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        startFg()
        if (capture == null && i != null && i.hasExtra("data")) {
            val data = readData(i)
            if (data == null) Bot.capStatus = "нет данных разрешения записи экрана"
            if (data != null) {
                val mp = (getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager)
                    .getMediaProjection(i.getIntExtra("code", 0), data)
                val (w, h) = U.screen(this)
                capture = Capture(mp, w, h, resources.displayMetrics.densityDpi)
            }
        }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        if (panel == null) buildUi()
        Bot.onStatus = { _ -> ui.post { statusTv?.text = Bot.logText(1) } }
        Bot.onProgress = { d, t, fr ->
            ui.post {
                icon?.text = "★ $d/$t"
                statusTv?.text = "Проверено $d из $t, свободных: $fr"
            }
        }
        Bot.onFinish = { list -> ui.post { showResult(list) } }
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("sf", "SIMFOUND", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "sf")
            .setContentTitle("SIMFOUND работает")
            .setSmallIcon(android.R.drawable.ic_menu_search).build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    // ---------- помощники ----------
    private fun d(v: Float) = Th.dp(this, v)

    private fun tv(t: String, sp: Float, c: Int = Th.TEXT, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = sp; setTextColor(c); typeface = Th.mono(bold)
    }

    private fun btn(t: String, filled: Boolean, click: () -> Unit) = TextView(this).apply {
        text = t; textSize = 13f; typeface = Th.mono(true); gravity = Gravity.CENTER
        setTextColor(Th.TEXT)
        setPadding(d(10f), d(12f), d(10f), d(12f))
        background = if (filled) Th.filled(this@FloatingService, 16f) else Th.glass(this@FloatingService, 16f)
        setOnClickListener { click() }
    }

    private fun lpw() = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        .apply { setMargins(d(4f), d(4f), d(4f), d(4f)) }

    private fun params(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START }

    private fun drag(handle: View, target: View, lp: WindowManager.LayoutParams) {
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        handle.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - sx).toInt(); val dy = (e.rawY - sy).toInt()
                    if (abs(dx) > 8 || abs(dy) > 8) moved = true
                    lp.x = ox + dx; lp.y = oy + dy
                    wm.updateViewLayout(target, lp); true
                }
                MotionEvent.ACTION_UP -> { if (!moved) v.performClick(); true }
                else -> false
            }
        }
    }

    private fun attachPanel() { if (!panelOn && panel != null) { try { wm.addView(panel, plp); panelOn = true } catch (e: Exception) {} } }
    private fun detachPanel() { if (panelOn) { try { wm.removeView(panel) } catch (e: Exception) {}; panelOn = false } }
    private fun attachIcon() { if (!iconOn && icon != null) { try { wm.addView(icon, ilp); iconOn = true } catch (e: Exception) {} } }
    private fun detachIcon() { if (iconOn) { try { wm.removeView(icon) } catch (e: Exception) {}; iconOn = false } }
    private fun collapse() { detachPanel(); attachIcon() }
    private fun expand() { detachIcon(); attachPanel() }

    private fun openUrl(u: String) {
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun scrollOf(v: View) = ScrollView(this).apply { addView(v) }

    // ---------- плавающее окно ----------
    private fun buildUi() {
        val (sw, sh) = U.screen(this)
        val pw = minOf(d(390f), (sw * 0.6f).toInt())
        val ph = minOf(d(300f), (sh * 0.85f).toInt())

        val root = FrameLayout(this)
        root.background = Th.glass(this, 22f, 0xFF0E0B1A.toInt(), Th.ACCENT_DARK)
        root.clipToOutline = true
        root.outlineProvider = ViewOutlineProvider.BACKGROUND
        root.addView(ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            U.bg(this@FloatingService, 2)?.let { setImageBitmap(it) }
        }, FrameLayout.LayoutParams(-1, -1))
        root.addView(View(this).apply { setBackgroundColor(Th.SCRIM) }, FrameLayout.LayoutParams(-1, -1))

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(d(14f), d(12f), d(14f), d(12f))
        }
        root.addView(col, FrameLayout.LayoutParams(-1, -1))

        // шапка
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(tv("★", 26f, Th.ACCENT, true).apply { setPadding(0, 0, d(10f), 0) })
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titles.addView(tv("Script SIMFOUND", 15f, Th.TEXT, true))
        titles.addView(tv("by kaiserpm", 11f, Th.MUTED))
        head.addView(titles, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(tv("✕", 20f, Th.TEXT, true).apply {
            setPadding(d(12f), d(4f), d(4f), d(4f)); setOnClickListener { collapse() }
        })
        col.addView(head)

        val tabsRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        col.addView(tabsRow, LinearLayout.LayoutParams(-1, -2).apply { topMargin = d(10f) })
        val content = FrameLayout(this)
        col.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))

        // вкладка «Запуск»
        val runCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val statusRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        statusRow.addView(tv("●", 14f, Th.ACCENT, true).apply { setPadding(0, 0, d(8f), 0) })
        statusTv = tv("Готово к запуску", 12f)
        statusRow.addView(statusTv, LinearLayout.LayoutParams(0, -2, 1f))
        runCol.addView(statusRow, LinearLayout.LayoutParams(-1, -2).apply { topMargin = d(6f); bottomMargin = d(10f) })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(btn("▶ СТАРТ", true) { collapse(); Bot.start(this) }, lpw())
        row.addView(btn("■ СТОП", false) { Bot.stop() }, lpw())
        row.addView(btn("Выход", false) { Bot.stop(); stopSelf() }, lpw())
        runCol.addView(row)
        val run = scrollOf(runCol)

        // вкладка «Инструкция»
        val guide = scrollOf(tv(T.GUIDE, 11f))

        // вкладка «Обратная связь»
        val fbCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fbCol.addView(tv("По всем вопросам обращайтесь в Telegram:", 13f))
        fbCol.addView(tv(U.tg(), 13f, Th.ACCENT, true))
        fbCol.addView(btn("Открыть Telegram", true) { openUrl(U.tg()) },
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = d(12f) })
        val fb = scrollOf(fbCol)

        val names = listOf("▶ Запуск", "⚙ Инструкция", "✉ Обратная связь")
        val views = listOf<View>(run, guide, fb)
        val tabs = ArrayList<TextView>()
        fun select(i: Int) {
            views.forEachIndexed { j, v -> v.visibility = if (i == j) View.VISIBLE else View.GONE }
            tabs.forEachIndexed { j, t ->
                t.background = if (i == j) Th.filled(this, 14f) else Th.glass(this, 14f)
            }
        }
        names.forEachIndexed { i, n ->
            val t = tv(n, 12f, Th.TEXT, true).apply {
                gravity = Gravity.CENTER
                setPadding(d(6f), d(10f), d(6f), d(10f))
                setOnClickListener { select(i) }
            }
            tabs.add(t); tabsRow.addView(t, LinearLayout.LayoutParams(0, -1, 1f).apply { setMargins(d(3f), 0, d(3f), 0) })
            content.addView(views[i], FrameLayout.LayoutParams(-1, -1).apply { topMargin = d(10f) })
        }
        select(0)

        plp = params(pw, ph).apply { x = d(8f); y = d(8f) }
        panel = root
        drag(head, root, plp)

        // свёрнутая иконка
        val ic = tv("★ SIMFOUND", 13f, Th.TEXT, true).apply {
            gravity = Gravity.CENTER
            setPadding(d(16f), d(10f), d(16f), d(10f))
            background = Th.filled(this@FloatingService, 22f)
            setOnClickListener { expand() }
        }
        ilp = params(-2, -2).apply { x = d(8f); y = d(8f) }
        icon = ic
        drag(ic, ic, ilp)
        attachPanel()
    }

    // ---------- итоговое окно ----------
    private fun showResult(list: List<String>) {
        statusTv?.text = "Готово. Найдено свободных: ${list.size}"
        icon?.text = "★ SIMFOUND"
        result?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        val text = if (list.isEmpty()) "Свободных номеров не найдено"
        else "Свободные комбинации номеров:\n" + list.joinToString("\n")

        val (_, sh) = U.screen(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(d(16f), d(14f), d(16f), d(14f))
            background = Th.glass(this@FloatingService, 22f, 0xF20E0B1A.toInt(), Th.ACCENT_DARK)
        }
        box.addView(tv("Перебор завершён", 16f, Th.ACCENT, true))
        if (Bot.summary.isNotEmpty()) box.addView(tv(Bot.summary, 11f, Th.MUTED),
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = d(4f) })
        val inner = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        inner.addView(tv(text, 14f))
        inner.addView(tv("Лог:\n" + Bot.logText(12), 10f, Th.MUTED),
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = d(10f) })
        box.addView(scrollOf(inner), LinearLayout.LayoutParams(d(340f), (sh * 0.38f).toInt()).apply { topMargin = d(10f) })

        fun copy(label: String, value: String, done: String) {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText(label, value))
            Toast.makeText(this, done, Toast.LENGTH_SHORT).show()
        }
        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row1.addView(btn("Копировать текст", true) { copy("sim", text, "Скопировано") }, lpw())
        row1.addView(btn("Копировать лог", false) { copy("log", Bot.summary + "\n" + Bot.logText(20), "Лог скопирован") }, lpw())
        box.addView(row1, LinearLayout.LayoutParams(-1, -2).apply { topMargin = d(10f) })
        box.addView(btn("Закрыть", false) {
            result?.let { try { wm.removeView(it) } catch (e: Exception) {} }
            result = null
        }, LinearLayout.LayoutParams(-1, -2).apply { setMargins(d(4f), d(2f), d(4f), 0) })

        val lp = params(-2, -2).apply { gravity = Gravity.CENTER }
        wm.addView(box, lp)
        result = box
    }

    override fun onDestroy() {
        Bot.stop()
        detachPanel(); detachIcon()
        result?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        capture?.release()
        super.onDestroy()
    }
}
