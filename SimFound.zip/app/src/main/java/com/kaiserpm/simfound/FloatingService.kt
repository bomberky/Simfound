package com.kaiserpm.simfound

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

class FloatingService : Service() {
    private lateinit var wm: WindowManager
    private val ui = Handler(Looper.getMainLooper())
    private var panel: View? = null
    private var icon: TextView? = null
    private var result: View? = null
    private var statusTv: TextView? = null
    private var capture: Capture? = null
    private val green = 0xFF39FF14.toInt()
    private lateinit var plp: WindowManager.LayoutParams
    private lateinit var ilp: WindowManager.LayoutParams

    override fun onBind(i: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    private fun readData(i: Intent): Intent? =
        if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra("data", Intent::class.java)
        else i.getParcelableExtra<Intent>("data")

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        startFg()
        if (capture == null && i != null && i.hasExtra("data")) {
            val data = readData(i)
            if (data != null) {
                val mp = (getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager)
                    .getMediaProjection(i.getIntExtra("code", 0), data)
                val (w, h) = U.screen(this)
                capture = Capture(mp, w, h, resources.displayMetrics.densityDpi)
            }
        }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        if (panel == null) buildUi()
        Bot.onStatus = { _ -> ui.post { statusTv?.text = Bot.logText(10) } }
        Bot.onProgress = { d, t, fr ->
            ui.post {
                icon?.text = "$d/$t"
                statusTv?.text = "Проверено $d из $t • свободных: $fr"
            }
        }
        Bot.onFinish = { list -> ui.post { showResult(list) } }
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("sf", "SIMFOUND", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "sf")
            .setContentTitle("SIMFOUND работает")
            .setSmallIcon(android.R.drawable.ic_menu_search).build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    // ---------- helpers ----------
    private fun d(v: Float) = (v * resources.displayMetrics.density).toInt()

    private fun tv(t: String, sp: Float, c: Int = Color.WHITE, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = sp; setTextColor(c)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun btn(t: String, bg: Int, fg: Int, click: () -> Unit) = TextView(this).apply {
        text = t; textSize = 13f; setTextColor(fg); gravity = Gravity.CENTER
        setTypeface(typeface, Typeface.BOLD)
        setPadding(d(10f), d(8f), d(10f), d(8f))
        background = GradientDrawable().apply { cornerRadius = d(10f).toFloat(); setColor(bg) }
        setOnClickListener { click() }
    }

    private fun lpw() = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        .apply { setMargins(d(3f), d(3f), d(3f), d(3f)) }

    private fun params(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START }

    private fun drag(handle: View, target: View, lp: WindowManager.LayoutParams) {
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        handle.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - sx).toInt(); val dy = (e.rawY - sy).toInt()
                    if (abs(dx) > 8 || abs(dy) > 8) moved = true
                    lp.x = ox + dx; lp.y = oy + dy
                    wm.updateViewLayout(target, lp); true
                }
                MotionEvent.ACTION_UP -> { if (!moved) v.performClick(); true }
                else -> false
            }
        }
    }

    private fun hideAll() { panel?.visibility = View.GONE; icon?.visibility = View.GONE }
    private fun collapse() { panel?.visibility = View.GONE; icon?.visibility = View.VISIBLE }
    private fun expand() { icon?.visibility = View.GONE; panel?.visibility = View.VISIBLE }

    private fun openUrl(u: String) {
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    // ---------- плавающее окно ----------
    private fun buildUi() {
        val root = FrameLayout(this)
        root.background = GradientDrawable().apply {
            cornerRadius = d(16f).toFloat(); setColor(Color.BLACK); setStroke(d(1.5f), green)
        }
        root.clipToOutline = true
        root.outlineProvider = ViewOutlineProvider.BACKGROUND

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(d(10f), d(8f), d(10f), d(8f))
            layoutParams = FrameLayout.LayoutParams(d(340f), d(250f))
        }
        val bgImg = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            U.bg(this@FloatingService, 2)?.let { setImageBitmap(it) }
        }
        val scrim = View(this).apply { setBackgroundColor(0xB0000000.toInt()) }
        root.addView(bgImg, FrameLayout.LayoutParams(-1, -1))
        root.addView(scrim, FrameLayout.LayoutParams(-1, -1))
        root.addView(col)
        // fixed-size overlay: root measures to col
        bgImg.layoutParams = FrameLayout.LayoutParams(-1, -1)

        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val title = tv("Skript SIMFOUND by kaiserpm", 14f, green, true)
        head.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(tv("✕", 18f, Color.WHITE, true).apply {
            setPadding(d(10f), 0, d(4f), 0); setOnClickListener { collapse() }
        })
        col.addView(head)

        val tabsRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        col.addView(tabsRow)
        val content = FrameLayout(this)
        col.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))

        // вкладка «Запуск»
        val run = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        statusTv = tv("Откройте магазин → «Услуги», затем нажмите СТАРТ (" + Bot.VERSION + ")", 11f)
        run.addView(statusTv)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(btn("▶ СТАРТ", green, Color.BLACK) { collapse(); Bot.start(this) }, lpw())
        row.addView(btn("■ СТОП", 0xFFE53935.toInt(), Color.WHITE) { Bot.stop() }, lpw())
        row.addView(btn("Тест", 0xFF1E88E5.toInt(), Color.WHITE) { Shell.requestPermission(); hideAll(); Bot.test(); ui.postDelayed({ expand() }, 9000) }, lpw())
        row.addView(btn("Выход", 0xFF444444.toInt(), Color.WHITE) { Bot.stop(); stopSelf() }, lpw())
        run.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = d(10f) })

        // вкладка «Инструкция»
        val guide = ScrollView(this).apply { addView(tv(T.GUIDE, 11f)) }

        // вкладка «Обратная связь»
        val fb = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fb.addView(tv("По всем вопросам обращайтесь в Telegram:", 13f))
        fb.addView(tv(U.tg(), 13f, green, true))
        fb.addView(btn("Открыть Telegram", green, Color.BLACK) { openUrl(U.tg()) },
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = d(10f) })

        val names = listOf("Запуск", "Инструкция", "Обратная связь")
        val views = listOf<View>(run, guide, fb)
        val tabs = ArrayList<TextView>()
        fun select(i: Int) {
            views.forEachIndexed { j, v -> v.visibility = if (i == j) View.VISIBLE else View.GONE }
            tabs.forEachIndexed { j, t ->
                t.setTextColor(if (i == j) Color.BLACK else Color.WHITE)
                (t.background as GradientDrawable).setColor(if (i == j) green else 0x55FFFFFF)
            }
        }
        names.forEachIndexed { i, n ->
            val t = tv(n, 12f, Color.WHITE, true).apply {
                gravity = Gravity.CENTER
                setPadding(d(4f), d(6f), d(4f), d(6f))
                background = GradientDrawable().apply { cornerRadius = d(8f).toFloat() }
                setOnClickListener { select(i) }
            }
            tabs.add(t); tabsRow.addView(t, lpw())
            content.addView(views[i], FrameLayout.LayoutParams(-1, -1).apply { topMargin = d(8f) })
        }
        select(0)

        plp = params(-2, -2).apply { x = d(8f); y = d(8f) }
        wm.addView(root, plp)
        panel = root
        drag(head, root, plp)

        // иконка (свёрнутое состояние)
        val ic = tv("SIMFOUND", 12f, Color.BLACK, true).apply {
            gravity = Gravity.CENTER
            setPadding(d(12f), d(8f), d(12f), d(8f))
            background = GradientDrawable().apply { cornerRadius = d(20f).toFloat(); setColor(green) }
            visibility = View.GONE
            setOnClickListener { expand() }
        }
        ilp = params(-2, -2).apply { x = d(8f); y = d(8f) }
        wm.addView(ic, ilp)
        icon = ic
        drag(ic, ic, ilp)
    }

    // ---------- итоговое окно ----------
    private fun showResult(list: List<String>) {
        statusTv?.text = "Готово. Найдено свободных: ${list.size}"
        icon?.text = "SIMFOUND"
        result?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        val text = if (list.isEmpty()) "Свободных номеров не найдено"
        else "Свободные комбинации номеров:\n" + list.joinToString("\n")

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(d(14f), d(12f), d(14f), d(12f))
            background = GradientDrawable().apply {
                cornerRadius = d(16f).toFloat(); setColor(0xF2101010.toInt()); setStroke(d(1.5f), green)
            }
        }
        box.addView(tv("Перебор завершён", 15f, green, true))
        val sv = ScrollView(this).apply { addView(tv(text, 14f)) }
        box.addView(sv, LinearLayout.LayoutParams(d(300f), d(130f)).apply { topMargin = d(8f) })
        box.addView(tv("Лог:\n" + Bot.logText(5), 10f, 0xFF999999.toInt()))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(btn("Копировать текст", green, Color.BLACK) {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("sim", text))
            Toast.makeText(this, "Скопировано", Toast.LENGTH_SHORT).show()
        }, lpw())
        row.addView(btn("Закрыть", 0xFF444444.toInt(), Color.WHITE) {
            result?.let { try { wm.removeView(it) } catch (e: Exception) {} }
            result = null
        }, lpw())
        box.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = d(8f) })

        val lp = params(-2, -2).apply { gravity = Gravity.CENTER }
        wm.addView(box, lp)
        result = box
    }

    override fun onDestroy() {
        Bot.stop()
        listOf(panel, icon, result).forEach { v -> v?.let { try { wm.removeView(it) } catch (e: Exception) {} } }
        capture?.release()
        super.onDestroy()
    }
}
