package com.kaiserpm.simfound

import android.content.Context
import android.content.pm.PackageManager
import android.os.SystemClock
import rikka.shizuku.Shizuku
import java.io.OutputStream

/** Нажатия и ввод через Shizuku (права shell) — так же, как это делает MacroDroid. */
object Shell {
    private var out: OutputStream? = null

    fun running(): Boolean = try { Shizuku.pingBinder() } catch (e: Throwable) { false }

    fun available(): Boolean = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) { false }

    fun requestPermission() {
        try {
            if (Shizuku.pingBinder() && Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED)
                Shizuku.requestPermission(100)
        } catch (e: Throwable) {}
    }

    private fun open(): Boolean = try {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java)
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh"), null, null) as Process
        out = p.outputStream
        true
    } catch (e: Throwable) {
        Bot.log("Shizuku: ${e.javaClass.simpleName} ${e.message}")
        false
    }

    @Synchronized
    fun exec(cmd: String): Boolean {
        if (out == null && !open()) return false
        return try {
            out!!.write((cmd + "\n").toByteArray()); out!!.flush(); true
        } catch (e: Throwable) { out = null; false }
    }

    /** Разовая команда с ожиданием и выводом (для диагностики). */
    fun run(cmd: String): String = try {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java)
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
        val o = p.inputStream.bufferedReader().readText()
        val e = p.errorStream.bufferedReader().readText()
        (o + e).trim()
    } catch (e: Throwable) { "ошибка: ${e.javaClass.simpleName} ${e.message}" }

    /** Включает невидимую клавиатуру SIMFOUND (старая запоминается). Возвращает статус для лога. */
    fun imeOn(ctx: Context): String {
        if (!available()) return "нет Shizuku"
        val me = ctx.packageName + "/" + SilentIme::class.java.name
        val cur = run("settings get secure default_input_method").trim()
        if (cur.isNotEmpty() && cur != "null" && !cur.startsWith(ctx.packageName))
            ctx.getSharedPreferences("p", Context.MODE_PRIVATE).edit().putString("ime_old", cur).apply()
        val r1 = run("ime enable $me").take(40)
        val r2 = run("ime set $me").take(40)
        SystemClock.sleep(500)
        var now = run("settings get secure default_input_method").trim()
        if (!now.startsWith(ctx.packageName)) {
            val en = run("settings get secure enabled_input_methods").trim()
            if (!en.contains(ctx.packageName)) {
                val list = if (en.isEmpty() || en == "null") me else "$en:$me"
                run("settings put secure enabled_input_methods $list")
            }
            run("settings put secure default_input_method $me")
            SystemClock.sleep(500)
            now = run("settings get secure default_input_method").trim()
        }
        return if (now.startsWith(ctx.packageName)) "вкл" else "НЕ ВКЛЮЧИЛАСЬ (сейчас: $now; enable=$r1; set=$r2)"
    }

    /** Быстро (без ожидания) подтверждает, что активна тихая клавиатура. */
    fun imeKeep(ctx: Context) {
        if (!available()) return
        exec("ime set " + ctx.packageName + "/" + SilentIme::class.java.name)
    }

    /** Возвращает прежнюю клавиатуру пользователя. */
    fun imeOff(ctx: Context) {
        if (!available()) return
        val old = ctx.getSharedPreferences("p", Context.MODE_PRIVATE).getString("ime_old", null) ?: return
        run("ime set $old")
    }

    fun tap(x: Float, y: Float): Boolean = exec("input tap ${x.toInt()} ${y.toInt()}")
    fun text(t: String): Boolean = exec("input text $t")
}
