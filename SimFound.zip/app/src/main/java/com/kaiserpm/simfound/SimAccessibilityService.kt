package com.kaiserpm.simfound

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class SimAccessibilityService : AccessibilityService() {
    override fun onServiceConnected() { Bot.a11y = this }
    override fun onUnbind(intent: Intent?): Boolean {
        if (Bot.a11y === this) Bot.a11y = null
        return super.onUnbind(intent)
    }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    /** Быстрое нажатие по долям экрана. */
    /** Нажатие по долям экрана. mode: способ нажатия (0..3), подбирается автоматически. */
    fun tap(p: FloatArray, mode: Int = Bot.tapMode) {
        val (w, h) = U.screen(this)
        val x = p[0] * w
        val y = p[1] * h
        val path = Path().apply {
            moveTo(x, y)
            if (mode >= 2) lineTo(x + 3f, y + 3f)
        }
        val dur = when (mode) { 0 -> 50L; 1 -> 120L; 2 -> 80L; else -> 200L }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, dur)).build()
        val ok = dispatchGesture(g, object : GestureResultCallback() {
            override fun onCancelled(d: GestureDescription?) { Bot.log("Нажатие отменено системой") }
        }, null)
        if (!ok) Bot.log("Система отклонила нажатие")
    }

    private fun findEditable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        if (n.isEditable) return n
        for (i in 0 until n.childCount) {
            val r = findEditable(n.getChild(i))
            if (r != null) return r
        }
        return null
    }

    private fun editable(): AccessibilityNodeInfo? {
        val root = rootInActiveWindow ?: return null
        val f = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (f != null && f.isEditable) return f
        return findEditable(root)
    }

    /** Вводит номер прямо в поле, без нажатий по клавиатуре. */
    fun enter(num: String): Boolean {
        val e = editable() ?: return false
        val b = Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, num)
        return e.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }
}
