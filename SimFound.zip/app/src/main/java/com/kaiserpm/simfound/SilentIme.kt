package com.kaiserpm.simfound

import android.inputmethodservice.InputMethodService
import android.view.View

/** Невидимая клавиатура: принимает номер от скрипта и не показывает ничего на экране. */
class SilentIme : InputMethodService() {
    companion object {
        @Volatile var inst: SilentIme? = null
        fun ready(): Boolean = inst?.currentInputConnection != null
        fun type(t: String): Boolean {
            val ic = inst?.currentInputConnection ?: return false
            ic.beginBatchEdit()
            ic.deleteSurroundingText(30, 30)
            ic.commitText(t, 1)
            ic.endBatchEdit()
            return true
        }
    }
    override fun onCreate() { super.onCreate(); inst = this }
    override fun onDestroy() { if (inst === this) inst = null; super.onDestroy() }
    override fun onEvaluateInputViewShown(): Boolean = false
    override fun onEvaluateFullscreenMode(): Boolean = false
    override fun onCreateInputView(): View? = null
}
