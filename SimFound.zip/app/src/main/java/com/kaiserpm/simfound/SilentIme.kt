package com.kaiserpm.simfound

import android.inputmethodservice.InputMethodService
import android.view.View
import android.view.inputmethod.EditorInfo

/** Невидимая клавиатура: принимает номер от скрипта и не показывает ничего на экране. */
class SilentIme : InputMethodService() {
    companion object {
        @Volatile var inst: SilentIme? = null
        @Volatile var session = 0   // растёт при каждом новом фокусе на поле ввода

        fun ready(): Boolean = inst?.currentInputConnection != null

        /** Вводит текст и проверяет, что он действительно оказался в поле. */
        fun type(t: String): Boolean {
            val ic = inst?.currentInputConnection ?: return false
            ic.beginBatchEdit()
            ic.deleteSurroundingText(30, 30)
            ic.commitText(t, 1)
            ic.endBatchEdit()
            val back = ic.getTextBeforeCursor(t.length + 6, 0)?.toString()
            return back == null || back.endsWith(t)   // null — поле не умеет отдавать текст, считаем успехом
        }
    }
    override fun onCreate() { super.onCreate(); inst = this }
    override fun onDestroy() { if (inst === this) inst = null; super.onDestroy() }
    override fun onStartInput(attribute: EditorInfo?, restarting: Boolean) {
        super.onStartInput(attribute, restarting)
        session++
    }
    override fun onEvaluateInputViewShown(): Boolean = false
    override fun onEvaluateFullscreenMode(): Boolean = false
    override fun onCreateInputView(): View? = null
}
