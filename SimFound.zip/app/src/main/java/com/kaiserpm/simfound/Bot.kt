package com.kaiserpm.simfound

import android.content.Context
import android.os.SystemClock

/** Цикл перебора. Работает по состояниям экрана, без фиксированных пауз. */
object Bot {
    const val NONE = 0
    const val CONFIRM_SVC = 1
    const val CONFIRM_NUM = 2
    const val NOFUNDS = 3
    const val INPUT = 4

    @Volatile var state = NONE
    @Volatile var running = false
    @Volatile var tapMode = 0
    @Volatile var cap = "кадров нет"
    @Volatile var capTs = 0L
    @Volatile var a11y: SimAccessibilityService? = null

    var onStatus: ((String) -> Unit)? = null
    var onProgress: ((Int, Int, Int) -> Unit)? = null
    var onFinish: ((List<String>) -> Unit)? = null

    private val logs = ArrayList<String>()
    fun log(s: String) {
        synchronized(logs) { logs.add(s); while (logs.size > 20) logs.removeAt(0) }
        onStatus?.invoke(s)
    }
    fun logText(n: Int): String = synchronized(logs) { logs.takeLast(n).joinToString("\n") }

    private fun waitFor(s: Int, ms: Long): Boolean {
        val end = SystemClock.uptimeMillis() + ms
        while (running && SystemClock.uptimeMillis() < end) {
            if (state == s) return true
            SystemClock.sleep(2)
        }
        return running && state == s
    }

    private fun waitLeave(s: Int, ms: Long) {
        val end = SystemClock.uptimeMillis() + ms
        while (running && SystemClock.uptimeMillis() < end && state == s) SystemClock.sleep(2)
    }

    /** Доводит игру до окна «Покупка телефонного номера». */
    private fun ready(svc: SimAccessibilityService): Boolean {
        for (attempt in 1..5) {
            if (!running) return false
            log("Шаг $attempt, экран=$state")
            when (state) {
                INPUT -> return true
                NOFUNDS -> { svc.tap(L.CLOSE); waitLeave(NOFUNDS, 800) }
                CONFIRM_NUM -> { svc.tap(L.NUM_CANCEL); waitLeave(CONFIRM_NUM, 800) }
                CONFIRM_SVC -> {
                    svc.tap(L.SVC_BUY)
                    if (waitFor(INPUT, 1500)) return true
                }
                else -> {
                    svc.tap(L.PHONE_ROW)
                    if (waitFor(CONFIRM_SVC, 1200)) {
                        svc.tap(L.SVC_BUY)
                        if (waitFor(INPUT, 1500)) return true
                    } else {
                        tapMode = (tapMode + 1) % 4
                        log("Меняю способ нажатия: $tapMode")
                    }
                }
            }
        }
        return state == INPUT
    }

    /** Вводит номер в поле без нажатий по клавиатуре. */
    private fun type(svc: SimAccessibilityService, n: String): Boolean {
        if (svc.enter(n)) return true
        svc.tap(L.FIELD)
        val end = SystemClock.uptimeMillis() + 700
        while (running && SystemClock.uptimeMillis() < end) {
            if (svc.enter(n)) return true
            SystemClock.sleep(25)
        }
        return false
    }

    fun start(ctx: Context) {
        if (running) return
        val svc = a11y
        if (svc == null) { log("Включите службу «SIMFOUND» в специальных возможностях"); return }
        running = true
        synchronized(logs) { logs.clear() }
        Thread { run(ctx.applicationContext, svc) }.start()
    }

    fun stop() { running = false }

    /** Проверка: пробует 4 способа нажатия на «Номер телефона» и находит рабочий. */
    fun test() {
        val svc = a11y
        synchronized(logs) { logs.clear() }
        if (svc == null) { log("Служба SIMFOUND не включена"); return }
        Thread {
            val age = if (capTs == 0L) -1 else SystemClock.uptimeMillis() - capTs
            log("Кадр: $cap, возраст $age мс")
            for (m in 0..3) {
                tapMode = m
                svc.tap(L.PHONE_ROW)
                SystemClock.sleep(900)
                if (state == CONFIRM_SVC || state == INPUT) {
                    log("РАБОТАЕТ способ $m")
                    svc.tap(L.SVC_CLOSE)
                    return@Thread
                }
                log("Способ $m: окно не открылось (экран=$state)")
            }
            log("Ни один способ не сработал")
        }.start()
    }

    private fun run(ctx: Context, svc: SimAccessibilityService) {
        val nums = U.numbers(ctx)
        val free = ArrayList<String>()
        log("Старт. Номеров в списке: ${nums.size}")
        var assumeInput = false
        try {
            for ((i, n) in nums.withIndex()) {
                if (!running) break
                if (!assumeInput && state != INPUT) {
                    if (!ready(svc)) { log("Не удалось открыть окно ввода номера (экран: $state)"); break }
                }
                if (!type(svc, n)) { log("Поле ввода недоступно для службы"); break }
                svc.tap(L.CONT)
                if (waitFor(CONFIRM_NUM, L.WAIT_NUM)) {
                    svc.tap(L.NUM_BUY)
                    if (waitFor(NOFUNDS, 2500)) {
                        free.add(n)
                        Store.save(ctx, n, "free")
                        svc.tap(L.CLOSE)
                        waitLeave(NOFUNDS, 800)
                        assumeInput = false
                    } else {
                        log("После «Покупка» нет «Недостаточно средств». Остановлено для безопасности")
                        break
                    }
                } else {
                    Store.save(ctx, n, "busy")
                    assumeInput = true
                }
                onProgress?.invoke(i + 1, nums.size, free.size)
            }
        } finally {
            running = false
            onFinish?.invoke(free)
        }
    }
}
