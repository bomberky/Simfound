package com.kaiserpm.simfound

import android.content.Context
import android.os.SystemClock
import kotlin.math.abs

/** Цикл перебора. Работает по состояниям экрана, без фиксированных пауз. */
object Bot {
    const val VERSION = "v22"
    const val NONE = 0
    const val CONFIRM_SVC = 1
    const val CONFIRM_NUM = 2
    const val NOFUNDS = 3
    const val INPUT = 4

    @Volatile var state = NONE
    @Volatile var running = false
    @Volatile var tapMode = 1
    @Volatile var popup = false
    @Volatile var summary = ""
    @Volatile var busyPx = ""
    @Volatile var confirmDt = 0L
    @Volatile private var inputAssumed = false
    @Volatile private var lastQuick = false
    private var lastKeep = 0L
    private var appCtx: Context? = null
    private var reasserted = false
    @Volatile var toast = ""
    @Volatile var toastTs = 0L
    @Volatile var toastCount = 0
    @Volatile var capStatus = "не запускалась"
    @Volatile var testing = false
    @Volatile var polling = false
    @Volatile var cap = "кадров нет"
    @Volatile var capTs = 0L
    @Volatile var a11y: SimAccessibilityService? = null

    var onStatus: ((String) -> Unit)? = null
    var onProgress: ((Int, Int, Int) -> Unit)? = null
    var onFinish: ((List<String>) -> Unit)? = null

    /** Определяет окно игры по цветам маркеров. get(x, y) отдаёт цвет 0xRRGGBB. */
    fun classifyPix(w: Int, h: Int, get: (Int, Int) -> Int): Int {
        fun hit(m: List<FloatArray>): Boolean {
            for (p in m) {
                val x = (p[0] * w).toInt().coerceIn(0, w - 1)
                val y = (p[1] * h).toInt().coerceIn(0, h - 1)
                val c = get(x, y)
                if (abs(((c shr 16) and 255) - p[2]) > 30 || abs(((c shr 8) and 255) - p[3]) > 30 ||
                    abs((c and 255) - p[4]) > 30) return false
            }
            return true
        }
        return when {
            hit(L.NOFUNDS) -> NOFUNDS
            hit(L.CONFIRM_NUM) -> CONFIRM_NUM
            hit(L.INPUT) -> INPUT
            hit(L.CONFIRM_SVC) -> CONFIRM_SVC
            else -> NONE
        }
    }

    /** Видна ли красная плашка «номер уже используется» (в трёх точках преобладает красный). */
    fun popupVisible(w: Int, h: Int, get: (Int, Int) -> Int): Boolean {
        for (p in L.BUSY) {
            val x = (p[0] * w).toInt().coerceIn(0, w - 1)
            val y = (p[1] * h).toInt().coerceIn(0, h - 1)
            val c = get(x, y)
            val r = (c shr 16) and 255; val g = (c shr 8) and 255; val b = c and 255
            if (r < 70 || r - g < 45 || r - b < 40) return false
        }
        return true
    }

    /** Цвета в точках плашки (для диагностики). */
    fun busyPixels(w: Int, h: Int, get: (Int, Int) -> Int): String =
        L.BUSY.joinToString(" ") { p ->
            val c = get((p[0] * w).toInt().coerceIn(0, w - 1), (p[1] * h).toInt().coerceIn(0, h - 1))
            "" + ((c shr 16) and 255) + "," + ((c shr 8) and 255) + "," + (c and 255)
        }

    /** Запасной канал: если записи экрана нет, берём скриншоты через службу специальных возможностей. */
    private fun startPoller(svc: SimAccessibilityService) {
        if (polling) return
        polling = true
        Thread {
            try {
                while (running || testing) {
                    if (capStatus != "кадры идут" || SystemClock.uptimeMillis() - capTs > 700) {
                        val b = svc.screenshot()
                        if (b != null) {
                            state = classifyPix(b.width, b.height) { x, y -> b.getPixel(x, y) and 0xFFFFFF }
                            popup = popupVisible(b.width, b.height) { x, y -> b.getPixel(x, y) and 0xFFFFFF }
                            busyPx = busyPixels(b.width, b.height) { x, y -> b.getPixel(x, y) and 0xFFFFFF }
                            cap = "скриншот ${b.width}x${b.height}"
                            capTs = SystemClock.uptimeMillis()
                            b.recycle()
                        } else SystemClock.sleep(150)
                    } else SystemClock.sleep(50)
                }
            } finally { polling = false }
        }.start()
    }

    private val logs = ArrayList<String>()

    /** Единая точка нажатия: Shizuku (режим 4) или служба специальных возможностей (0..3). */
    fun tap(svc: SimAccessibilityService, p: FloatArray) {
        if (tapMode == 4) {
            val (w, h) = U.screen(svc)
            if (Shell.tap(p[0] * w, p[1] * h)) return
            log("Shizuku недоступен, нажимаю через службу")
        }
        svc.tap(p, if (tapMode > 3) 0 else tapMode)
    }

    private fun nextMode() {
        tapMode = (tapMode + 1) % 5
        if (tapMode == 4 && !Shell.available()) tapMode = 0
    }
    fun log(s: String) {
        synchronized(logs) { logs.add(s); while (logs.size > 20) logs.removeAt(0) }
        onStatus?.invoke(s)
    }
    fun logText(n: Int): String = synchronized(logs) { logs.takeLast(n).joinToString("\n") }

    private fun waitFor(s: Int, ms: Long): Boolean {
        val end = SystemClock.uptimeMillis() + ms
        while (running && SystemClock.uptimeMillis() < end) {
            if (state == s) return true
            SystemClock.sleep(2)
        }
        return running && state == s
    }

    /** Ждёт окно «Подтверждение» (1) или красную плашку «номер уже используется» (2). 0 — время вышло. */
    private fun waitNumOrBusy(since: Long, ms: Long, popupBefore: Boolean): Int {
        var clear = !popupBefore   // плашка от прошлого номера не считается
        val end = SystemClock.uptimeMillis() + ms
        while (running && SystemClock.uptimeMillis() < end) {
            if (state == CONFIRM_NUM) { confirmDt = SystemClock.uptimeMillis() - since; return 1 }
            if (!popup) clear = true
            if (popup && clear) return 2
            if (toastTs > since) {
                val t = toast.lowercase()
                if (t.contains("занят") || t.contains("использ")) return 2
            }
            SystemClock.sleep(2)
        }
        return if (running && state == CONFIRM_NUM) 1 else 0
    }

    private fun waitLeave(s: Int, ms: Long) {
        val end = SystemClock.uptimeMillis() + ms
        while (running && SystemClock.uptimeMillis() < end && state == s) SystemClock.sleep(2)
    }

    /** Доводит игру до окна «Покупка телефонного номера». */
    private fun ready(svc: SimAccessibilityService): Boolean {
        for (attempt in 1..5) {
            if (!running) return false
            log("Шаг $attempt, экран=$state")
            when (state) {
                INPUT -> return true
                NOFUNDS -> { tap(svc, L.CLOSE); waitLeave(NOFUNDS, 800) }
                CONFIRM_NUM -> { tap(svc, L.NUM_CANCEL); waitLeave(CONFIRM_NUM, 800) }
                CONFIRM_SVC -> {
                    tap(svc, L.SVC_BUY)
                    if (waitFor(INPUT, 1500)) return true
                }
                else -> {
                    tap(svc, L.PHONE_ROW)
                    if (waitFor(CONFIRM_SVC, 1200)) {
                        tap(svc, L.SVC_BUY)
                        if (waitFor(INPUT, 1500)) return true
                    } else {
                        nextMode()
                        log("Меняю способ нажатия: $tapMode")
                    }
                }
            }
        }
        return state == INPUT
    }

    /** Быстро открывает окно ввода после свободного номера: нажатия подряд с короткими паузами. */
    private fun reopenFast(svc: SimAccessibilityService) {
        SystemClock.sleep(L.REOPEN_1)
        tap(svc, L.PHONE_ROW)
        SystemClock.sleep(L.REOPEN_2)
        tap(svc, L.SVC_BUY)
        SystemClock.sleep(L.REOPEN_3)
    }

    /** Вводит номер в поле: через невидимую клавиатуру (экранная не показывается). */
    private fun type(svc: SimAccessibilityService, n: String, quick: Boolean): Boolean {
        lastQuick = false
        if (quick) {
            // окно ввода после «занят» уже открыто и в фокусе: сразу вводим, без нажатия на поле и пауз
            if (SilentIme.ready() && SilentIme.type(n)) { path("тихая клавиатура"); lastQuick = true; return true }
            if (svc.enter(n)) { path("служба специальных возможностей"); keepIme(); lastQuick = true; return true }
        }
        val s0 = SilentIme.session
        tap(svc, L.FIELD)
        // ждём, пока поле реально получит фокус (новая сессия ввода), иначе текст уйдёт «в пустоту»
        val t0 = SystemClock.uptimeMillis()
        while (running && SilentIme.session == s0 && SystemClock.uptimeMillis() - t0 < 700) SystemClock.sleep(15)
        SystemClock.sleep(L.FOCUS_DELAY)
        val end = SystemClock.uptimeMillis() + 900
        while (running && SystemClock.uptimeMillis() < end) {
            if (SilentIme.ready() && SilentIme.type(n)) { path("тихая клавиатура"); return true }
            if (svc.enter(n)) { path("служба специальных возможностей (клавиатура может мелькать)"); reassertIme(); keepIme(); return true }
            SystemClock.sleep(25)
        }
        if (Shell.available() && (state == INPUT || inputAssumed)) { path("Shizuku input text (клавиатура видна)"); reassertIme(); keepIme(); return Shell.text(n) }
        return false
    }

    private fun keepIme() {
        val c = appCtx ?: return
        val now = SystemClock.uptimeMillis()
        if (now - lastKeep < 3000) return
        lastKeep = now
        Shell.imeKeep(c)
    }

    /** Если ввод пошёл мимо тихой клавиатуры — показываем в логе текущую и включаем заново. */
    private fun reassertIme() {
        if (reasserted) return
        reasserted = true
        val c = appCtx ?: return
        if (!Shell.available()) return
        log("Клавиатура сейчас: " + Shell.run("settings get secure default_input_method").trim().take(60))
        log("Включаю тихую заново: " + Shell.imeOn(c))
    }

    private var lastPath = ""
    private fun path(p: String) { if (p != lastPath) { lastPath = p; log("Ввод: $p") } }

    fun start(ctx: Context) {
        if (running) return
        val svc = a11y
        if (svc == null) { log("Включите службу «SIMFOUND» в специальных возможностях"); return }
        appCtx = ctx.applicationContext
        reasserted = false
        running = true
        synchronized(logs) { logs.clear() }
        startPoller(svc)
        Thread { run(ctx.applicationContext, svc) }.start()
    }

    fun stop() { running = false }

    /** Проверка: пробует способы нажатия на кнопку «200 GC» и находит рабочий. */
    fun test() {
        val svc = a11y
        synchronized(logs) { logs.clear() }
        if (svc == null) { log("Служба SIMFOUND не включена"); return }
        testing = true
        startPoller(svc)
        Thread {
          try {
            log("Версия ${VERSION}")
            log("Запись экрана: $capStatus")
            val sh = if (Shell.available()) "подключён" else if (Shell.running()) "нет разрешения" else "не запущен"
            log("Shizuku: $sh")
            if (Shell.available()) log("id: " + Shell.run("id").take(70))
            for (m in 0..4) {
                if (m == 4 && !Shell.available()) break
                tapMode = m
                if (m == 4) {
                    val (w, h) = U.screen(svc)
                    val r = Shell.run("input tap ${(L.PHONE_ROW[0] * w).toInt()} ${(L.PHONE_ROW[1] * h).toInt()}; echo rc=$?")
                    log("input: " + r.take(70))
                } else tap(svc, L.PHONE_ROW)
                SystemClock.sleep(900)
                if (state == CONFIRM_SVC || state == INPUT) {
                    log("РАБОТАЕТ способ $m")
                    tap(svc, L.SVC_CLOSE)
                    return@Thread
                }
                log("Способ $m: окно не открылось (экран=$state)")
            }
            log("Ни один способ не сработал. Кадр: $cap")
            if (Shell.available()) tapMode = 4
          } finally { testing = false }
        }.start()
    }

    private fun run(ctx: Context, svc: SimAccessibilityService) {
        val nums = U.numbers(ctx)
        val free = ArrayList<String>()
        log("Старт. Номеров в списке: ${nums.size}")
        val slow = capStatus != "кадры идут"
        val baseWait = if (slow) 900L else 600L
        var maxDt = 0L
        var confirmSeen = 0
        var pxLogged = 0
        var i = 0
        var fails = 0
        var busyLogged = false
        var assumeInput = false
        var reason = "список пройден до конца"
        var lastTyped: String? = null
        var busyConfirmed = 0
        var busyTimer = 0
        var unknownCnt = 0
        try {
            log("Тихая клавиатура: " + Shell.imeOn(ctx))
            while (running && i < nums.size) {
                val n = nums[i]
                inputAssumed = assumeInput
                if (state == CONFIRM_NUM && lastTyped != null) {
                    // подтверждение появилось с опозданием: прошлый номер на самом деле свободен
                    val n0 = lastTyped!!
                    tap(svc, L.NUM_BUY)
                    if (waitFor(NOFUNDS, 3000)) {
                        if (n0 !in free) free.add(n0)
                        Store.save(ctx, n0, "free")
                        log("Свободен (подтверждение пришло позже): $n0")
                        tap(svc, L.CLOSE)
                        reopenFast(svc)
                        assumeInput = true
                    } else {
                        log("После «Покупка» нет «Недостаточно средств» ($n0), иду дальше")
                        Store.save(ctx, n0, "unknown")
                        assumeInput = false
                    }
                    lastTyped = null
                    continue
                }
                val stray = state == CONFIRM_NUM || state == NOFUNDS || state == CONFIRM_SVC
                if (stray || (!assumeInput && state != INPUT)) {
                    // после «номер занят» окно может вернуться не сразу — даём ему секунду
                    val back = !stray && waitFor(INPUT, 800)
                    if (!back && !ready(svc)) {
                        fails++
                        log("Не открылось окно ввода (экран: $state), попытка $fails из 4")
                        if (fails >= 4) { reason = "не удалось открыть окно ввода номера"; break }
                        continue
                    }
                }
                if (!type(svc, n, assumeInput)) {
                    assumeInput = false
                    fails++
                    log("Поле ввода недоступно, попытка $fails из 4")
                    if (fails >= 4) { reason = "поле ввода номера недоступно"; break }
                    continue
                }
                SystemClock.sleep(if (lastQuick) 80L else L.TYPE_DELAY)
                val since = SystemClock.uptimeMillis()
                val popupBefore = popup
                lastTyped = n
                tap(svc, L.CONT)
                val waitNum = if (confirmSeen >= 3) maxOf(500L, minOf(1400L, (maxDt * 1.35).toLong())) else baseWait
                val r = waitNumOrBusy(since, if (popupBefore) minOf(waitNum, 650L) else waitNum, popupBefore)
                if (r == 0 && pxLogged < 3) { pxLogged++; log("Пиксели плашки при таймере: $busyPx") }
                if (r == 2 && !busyLogged) { busyLogged = true; log("«Занят» определён по красной плашке") }
                if (r == 1) {
                    lastTyped = null
                    confirmSeen++
                    if (confirmDt > maxDt) maxDt = confirmDt
                    free.add(n)
                    Store.save(ctx, n, "free")
                    tap(svc, L.NUM_BUY)
                    if (waitFor(NOFUNDS, 3000)) {
                        tap(svc, L.CLOSE)
                        reopenFast(svc)
                        assumeInput = true
                    } else {
                        free.remove(n)
                        log("После «Покупка» нет «Недостаточно средств» ($n), иду дальше")
                        Store.save(ctx, n, "unknown")
                        unknownCnt++
                        assumeInput = false
                    }
                } else {
                    assumeInput = true
                    if (r == 2) busyConfirmed++ else busyTimer++
                    Store.save(ctx, n, "busy")
                }
                fails = 0
                i++
                if (i % 8 == 0) keepIme()
                onProgress?.invoke(i, nums.size, free.size)
            }
        } finally {
            running = false
            Shell.imeOff(ctx)
            if (toastCount == 0) log("Всплывающие сообщения службе не видны: «занят» определяется по таймеру")
            if (!running && reason == "список пройден до конца" && i < nums.size) reason = "остановлено кнопкой СТОП"
            summary = "Проверено $i из ${nums.size}: свободных ${free.size}, занято по плашке $busyConfirmed, по таймеру $busyTimer, неясных $unknownCnt. Окно подтверждения приходит за ≤${maxDt} мс. Итог: $reason"
            log("Готово: проверено $i из ${nums.size}")
            onFinish?.invoke(free)
        }
    }
}
