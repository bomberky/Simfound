package com.kaiserpm.simfound

import android.content.Context
import android.os.SystemClock
import kotlin.math.abs

/** Цикл перебора. Работает по состояниям экрана, без фиксированных пауз. */
object Bot {
    const val VERSION = "v10"
    const val NONE = 0
    const val CONFIRM_SVC = 1
    const val CONFIRM_NUM = 2
    const val NOFUNDS = 3
    const val INPUT = 4

    @Volatile var state = NONE
    @Volatile var running = false
    @Volatile var tapMode = 1
    @Volatile var capStatus = "не запускалась"
    @Volatile var testing = false
    @Volatile var polling = false
    @Volatile var cap = "кадров нет"
    @Volatile var capTs = 0L
    @Volatile var a11y: SimAccessibilityService? = null

    var onStatus: ((String) -> Unit)? = null
    var onProgress: ((Int, Int, Int) -> Unit)? = null
    var onFinish: ((List<String>) -> Unit)? = null

    /** Определяет окно игры по цветам маркеров. get(x, y) отдаёт цвет 0xRRGGBB. */
    fun classifyPix(w: Int, h: Int, get: (Int, Int) -> Int): Int {
        fun hit(m: List<FloatArray>): Boolean {
            for (p in m) {
                val x = (p[0] * w).toInt().coerceIn(0, w - 1)
                val y = (p[1] * h).toInt().coerceIn(0, h - 1)
                val c = get(x, y)
                if (abs(((c shr 16) and 255) - p[2]) > 30 || abs(((c shr 8) and 255) - p[3]) > 30 ||
                    abs((c and 255) - p[4]) > 30) return false
            }
            return true
        }
        return when {
            hit(L.NOFUNDS) -> NOFUNDS
            hit(L.CONFIRM_NUM) -> CONFIRM_NUM
            hit(L.INPUT) -> INPUT
            hit(L.CONFIRM_SVC) -> CONFIRM_SVC
            else -> NONE
        }
    }

    /** Запасной канал: если записи экрана нет, берём скриншоты через службу специальных возможностей. */
    private fun startPoller(svc: SimAccessibilityService) {
        if (polling) return
        polling = true
        Thread {
            try {
                while (running || testing) {
                    if (capStatus != "кадры идут" || SystemClock.uptimeMillis() - capTs > 700) {
                        val b = svc.screenshot()
                        if (b != null) {
                            state = classifyPix(b.width, b.height) { x, y -> b.getPixel(x, y) and 0xFFFFFF }
                            cap = "скриншот ${b.width}x${b.height}"
                            capTs = SystemClock.uptimeMillis()
                            b.recycle()
                        } else SystemClock.sleep(150)
                    } else SystemClock.sleep(50)
                }
            } finally { polling = false }
        }.start()
    }

    private val logs = ArrayList<String>()

    /** Единая точка нажатия: Shizuku (режим 4) или служба специальных возможностей (0..3). */
    fun tap(svc: SimAccessibilityService, p: FloatArray) {
        if (tapMode == 4) {
            val (w, h) = U.screen(svc)
            if (Shell.tap(p[0] * w, p[1] * h)) return
            log("Shizuku недоступен, нажимаю через службу")
        }
        svc.tap(p, if (tapMode > 3) 0 else tapMode)
    }

    private fun nextMode() {
        tapMode = (tapMode + 1) % 5
        if (tapMode == 4 && !Shell.available()) tapMode = 0
    }
    fun log(s: String) {
        synchronized(logs) { logs.add(s); while (logs.size > 20) logs.removeAt(0) }
        onStatus?.invoke(s)
    }
    fun logText(n: Int): String = synchronized(logs) { logs.takeLast(n).joinToString("\n") }

    private fun waitFor(s: Int, ms: Long): Boolean {
        val end = SystemClock.uptimeMillis() + ms
        while (running && SystemClock.uptimeMillis() < end) {
            if (state == s) return true
            SystemClock.sleep(2)
        }
        return running && state == s
    }

    private fun waitLeave(s: Int, ms: Long) {
        val end = SystemClock.uptimeMillis() + ms
        while (running && SystemClock.uptimeMillis() < end && state == s) SystemClock.sleep(2)
    }

    /** Доводит игру до окна «Покупка телефонного номера». */
    private fun ready(svc: SimAccessibilityService): Boolean {
        for (attempt in 1..5) {
            if (!running) return false
            log("Шаг $attempt, экран=$state")
            when (state) {
                INPUT -> return true
                NOFUNDS -> { tap(svc, L.CLOSE); waitLeave(NOFUNDS, 800) }
                CONFIRM_NUM -> { tap(svc, L.NUM_CANCEL); waitLeave(CONFIRM_NUM, 800) }
                CONFIRM_SVC -> {
                    tap(svc, L.SVC_BUY)
                    if (waitFor(INPUT, 1500)) return true
                }
                else -> {
                    tap(svc, L.PHONE_ROW)
                    if (waitFor(CONFIRM_SVC, 1200)) {
                        tap(svc, L.SVC_BUY)
                        if (waitFor(INPUT, 1500)) return true
                    } else {
                        nextMode()
                        log("Меняю способ нажатия: $tapMode")
                    }
                }
            }
        }
        return state == INPUT
    }

    /** Вводит номер в поле: через невидимую клавиатуру (экранная не показывается). */
    private fun type(svc: SimAccessibilityService, n: String): Boolean {
        tap(svc, L.FIELD)
        SystemClock.sleep(L.FOCUS_DELAY)
        val end = SystemClock.uptimeMillis() + 900
        while (running && SystemClock.uptimeMillis() < end) {
            if (SilentIme.ready() && SilentIme.type(n)) return true
            if (svc.enter(n)) return true
            SystemClock.sleep(25)
        }
        if (Shell.available()) return Shell.text(n)
        return false
    }

    fun start(ctx: Context) {
        if (running) return
        val svc = a11y
        if (svc == null) { log("Включите службу «SIMFOUND» в специальных возможностях"); return }
        running = true
        synchronized(logs) { logs.clear() }
        startPoller(svc)
        Thread { run(ctx.applicationContext, svc) }.start()
    }

    fun stop() { running = false }

    /** Проверка: пробует способы нажатия на кнопку «200 GC» и находит рабочий. */
    fun test() {
        val svc = a11y
        synchronized(logs) { logs.clear() }
        if (svc == null) { log("Служба SIMFOUND не включена"); return }
        testing = true
        startPoller(svc)
        Thread {
          try {
            log("Версия ${VERSION}")
            log("Запись экрана: $capStatus")
            val sh = if (Shell.available()) "подключён" else if (Shell.running()) "нет разрешения" else "не запущен"
            log("Shizuku: $sh")
            if (Shell.available()) log("id: " + Shell.run("id").take(70))
            for (m in 0..4) {
                if (m == 4 && !Shell.available()) break
                tapMode = m
                if (m == 4) {
                    val (w, h) = U.screen(svc)
                    val r = Shell.run("input tap ${(L.PHONE_ROW[0] * w).toInt()} ${(L.PHONE_ROW[1] * h).toInt()}; echo rc=$?")
                    log("input: " + r.take(70))
                } else tap(svc, L.PHONE_ROW)
                SystemClock.sleep(900)
                if (state == CONFIRM_SVC || state == INPUT) {
                    log("РАБОТАЕТ способ $m")
                    tap(svc, L.SVC_CLOSE)
                    return@Thread
                }
                log("Способ $m: окно не открылось (экран=$state)")
            }
            log("Ни один способ не сработал. Кадр: $cap")
            if (Shell.available()) tapMode = 4
          } finally { testing = false }
        }.start()
    }

    private fun run(ctx: Context, svc: SimAccessibilityService) {
        val nums = U.numbers(ctx)
        val free = ArrayList<String>()
        log("Старт. Номеров в списке: ${nums.size}")
        var assumeInput = false
        val slow = capStatus != "кадры идут"
        val waitNum = if (slow) L.WAIT_NUM * 2 else L.WAIT_NUM
        try {
            Shell.imeOn(ctx)
            log("Тихая клавиатура: " + (if (SilentIme.inst != null || Shell.available()) "вкл" else "нет Shizuku"))
            for ((i, n) in nums.withIndex()) {
                if (!running) break
                val stray = state == CONFIRM_NUM || state == NOFUNDS || state == CONFIRM_SVC
                if (stray || (!assumeInput && state != INPUT)) {
                    if (!ready(svc)) { log("Не удалось открыть окно ввода номера (экран: $state)"); break }
                }
                if (!type(svc, n)) { log("Поле ввода недоступно для службы"); break }
                SystemClock.sleep(L.TYPE_DELAY)
                tap(svc, L.CONT)
                if (waitFor(CONFIRM_NUM, waitNum)) {
                    tap(svc, L.NUM_BUY)
                    if (waitFor(NOFUNDS, 2500)) {
                        free.add(n)
                        Store.save(ctx, n, "free")
                        tap(svc, L.CLOSE)
                        waitLeave(NOFUNDS, 800)
                        assumeInput = false
                    } else {
                        log("После «Покупка» нет «Недостаточно средств». Остановлено для безопасности")
                        break
                    }
                } else {
                    Store.save(ctx, n, "busy")
                    assumeInput = true
                }
                onProgress?.invoke(i + 1, nums.size, free.size)
            }
        } finally {
            running = false
            Shell.imeOff(ctx)
            onFinish?.invoke(free)
        }
    }
}
