package com.kaiserpm.simfound

import android.content.Context
import android.os.SystemClock

/** Цикл перебора. Работает по состояниям экрана, без фиксированных пауз. */
object Bot {
    const val VERSION = "v6"
    const val NONE = 0
    const val CONFIRM_SVC = 1
    const val CONFIRM_NUM = 2
    const val NOFUNDS = 3
    const val INPUT = 4

    @Volatile var state = NONE
    @Volatile var running = false
    @Volatile var tapMode = 0
    @Volatile var cap = "кадров нет"
    @Volatile var capTs = 0L
    @Volatile var a11y: SimAccessibilityService? = null

    var onStatus: ((String) -> Unit)? = null
    var onProgress: ((Int, Int, Int) -> Unit)? = null
    var onFinish: ((List<String>) -> Unit)? = null

    private val logs = ArrayList<String>()

    /** Единая точка нажатия: Shizuku (режим 4) или служба специальных возможностей (0..3). */
    fun tap(svc: SimAccessibilityService, p: FloatArray) {
        if (tapMode == 4) {
            val (w, h) = U.screen(svc)
            if (Shell.tap(p[0] * w, p[1] * h)) return
            log("Shizuku недоступен, нажимаю через службу")
        }
        svc.tap(p, if (tapMode > 3) 0 else tapMode)
    }

    private fun nextMode() {
        tapMode = (tapMode + 1) % 5
        if (tapMode == 4 && !Shell.available()) tapMode = 0
    }
    fun log(s: String) {
        synchronized(logs) { logs.add(s); while (logs.size > 20) logs.removeAt(0) }
        onStatus?.invoke(s)
    }
    fun logText(n: Int): String = synchronized(logs) { logs.takeLast(n).joinToString("\n") }

    private fun waitFor(s: Int, ms: Long): Boolean {
        val end = SystemClock.uptimeMillis() + ms
        while (running && SystemClock.uptimeMillis() < end) {
            if (state == s) return true
            SystemClock.sleep(2)
        }
        return running && state == s
    }

    private fun waitLeave(s: Int, ms: Long) {
        val end = SystemClock.uptimeMillis() + ms
        while (running && SystemClock.uptimeMillis() < end && state == s) SystemClock.sleep(2)
    }

    /** Доводит игру до окна «Покупка телефонного номера». */
    private fun ready(svc: SimAccessibilityService): Boolean {
        for (attempt in 1..5) {
            if (!running) return false
            log("Шаг $attempt, экран=$state")
            when (state) {
                INPUT -> return true
                NOFUNDS -> { tap(svc, L.CLOSE); waitLeave(NOFUNDS, 800) }
                CONFIRM_NUM -> { tap(svc, L.NUM_CANCEL); waitLeave(CONFIRM_NUM, 800) }
                CONFIRM_SVC -> {
                    tap(svc, L.SVC_BUY)
                    if (waitFor(INPUT, 1500)) return true
                }
                else -> {
                    tap(svc, L.PHONE_ROW)
                    if (waitFor(CONFIRM_SVC, 1200)) {
                        tap(svc, L.SVC_BUY)
                        if (waitFor(INPUT, 1500)) return true
                    } else {
                        nextMode()
                        log("Меняю способ нажатия: $tapMode")
                    }
                }
            }
        }
        return state == INPUT
    }

    /** Вводит номер в поле без нажатий по клавиатуре. */
    private fun type(svc: SimAccessibilityService, n: String): Boolean {
        if (svc.enter(n)) return true
        tap(svc, L.FIELD)
        val end = SystemClock.uptimeMillis() + 700
        while (running && SystemClock.uptimeMillis() < end) {
            if (svc.enter(n)) return true
            SystemClock.sleep(25)
        }
        if (Shell.available()) return Shell.text(n)
        return false
    }

    fun start(ctx: Context) {
        if (running) return
        val svc = a11y
        if (svc == null) { log("Включите службу «SIMFOUND» в специальных возможностях"); return }
        if (Shell.available()) tapMode = 4
        running = true
        synchronized(logs) { logs.clear() }
        Thread { run(ctx.applicationContext, svc) }.start()
    }

    fun stop() { running = false }

    /** Проверка: пробует способы нажатия на кнопку «200 GC» и находит рабочий. */
    fun test() {
        val svc = a11y
        synchronized(logs) { logs.clear() }
        if (svc == null) { log("Служба SIMFOUND не включена"); return }
        Thread {
            log("Версия ${VERSION}")
            val sh = if (Shell.available()) "подключён" else if (Shell.running()) "нет разрешения" else "не запущен"
            log("Shizuku: $sh")
            if (Shell.available()) log("id: " + Shell.run("id").take(70))
            for (m in 0..4) {
                if (m == 4 && !Shell.available()) break
                tapMode = m
                if (m == 4) {
                    val (w, h) = U.screen(svc)
                    val r = Shell.run("input tap ${(L.PHONE_ROW[0] * w).toInt()} ${(L.PHONE_ROW[1] * h).toInt()}; echo rc=$?")
                    log("input: " + r.take(70))
                } else tap(svc, L.PHONE_ROW)
                SystemClock.sleep(900)
                if (state == CONFIRM_SVC || state == INPUT) {
                    log("РАБОТАЕТ способ $m")
                    tap(svc, L.SVC_CLOSE)
                    return@Thread
                }
                log("Способ $m: окно не открылось (экран=$state)")
            }
            log("Ни один способ не сработал. Кадр: $cap")
            if (Shell.available()) tapMode = 4
        }.start()
    }

    private fun run(ctx: Context, svc: SimAccessibilityService) {
        val nums = U.numbers(ctx)
        val free = ArrayList<String>()
        log("Старт. Номеров в списке: ${nums.size}")
        var assumeInput = false
        try {
            for ((i, n) in nums.withIndex()) {
                if (!running) break
                if (!assumeInput && state != INPUT) {
                    if (!ready(svc)) { log("Не удалось открыть окно ввода номера (экран: $state)"); break }
                }
                if (!type(svc, n)) { log("Поле ввода недоступно для службы"); break }
                tap(svc, L.CONT)
                if (waitFor(CONFIRM_NUM, L.WAIT_NUM)) {
                    tap(svc, L.NUM_BUY)
                    if (waitFor(NOFUNDS, 2500)) {
                        free.add(n)
                        Store.save(ctx, n, "free")
                        tap(svc, L.CLOSE)
                        waitLeave(NOFUNDS, 800)
                        assumeInput = false
                    } else {
                        log("После «Покупка» нет «Недостаточно средств». Остановлено для безопасности")
                        break
                    }
                } else {
                    Store.save(ctx, n, "busy")
                    assumeInput = true
                }
                onProgress?.invoke(i + 1, nums.size, free.size)
            }
        } finally {
            running = false
            onFinish?.invoke(free)
        }
    }
}
