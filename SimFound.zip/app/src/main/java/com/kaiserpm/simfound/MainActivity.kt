package com.kaiserpm.simfound

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var keyEt: EditText
    private val prefs by lazy { getSharedPreferences("p", MODE_PRIVATE) }

    private fun d(v: Float) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        build()
        showIntro()
    }

    override fun onResume() {
        super.onResume()
        if (prefs.getBoolean("pending", false)) {
            prefs.edit().putBoolean("pending", false).apply()
            proceed(true)
        }
    }

    private fun btn(t: String, filled: Boolean, click: () -> Unit) = TextView(this).apply {
        text = t; textSize = 15f; typeface = Th.mono(true); gravity = Gravity.CENTER
        setTextColor(Th.TEXT)
        setPadding(d(12f), d(14f), d(12f), d(14f))
        background = if (filled) Th.filled(this@MainActivity, 24f) else Th.glass(this@MainActivity, 24f)
        setOnClickListener { click() }
    }

    private fun build() {
        val bmp = U.bg(this, 1)
        val root = FrameLayout(this).apply { setBackgroundColor(0xFF0E0B1A.toInt()) }
        root.addView(ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP; bmp?.let { setImageBitmap(it) }
        }, FrameLayout.LayoutParams(-1, -1))
        root.addView(View(this).apply { setBackgroundColor(0x660E0B1A) }, FrameLayout.LayoutParams(-1, -1))

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(d(16f), d(20f), d(16f), d(20f))
        }
        val cp = { LinearLayout.LayoutParams(d(420f), -2).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = d(12f) } }

        // верхняя плашка
        col.addView(TextView(this).apply {
            text = "Telegram kaiserpm"; textSize = 24f; setTextColor(Th.PINK)
            typeface = Th.mono(true); gravity = Gravity.CENTER
        }, cp())
        col.addView(btn("🔒  Перейти в ТГК", false) {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(U.tg())))
        }.apply { background = Th.glass(this@MainActivity, 24f, Th.GLASS, Th.ACCENT_DARK) },
            LinearLayout.LayoutParams(d(320f), -2).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = d(12f) })

        keyEt = EditText(this).apply {
            hint = "Введите ключ"; setHintTextColor(Th.MUTED); setTextColor(Th.TEXT)
            typeface = Th.mono(false)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            setSingleLine(); gravity = Gravity.CENTER
            setPadding(d(12f), d(14f), d(12f), d(14f))
            background = Th.glass(this@MainActivity, 24f, 0x66000000, Th.ACCENT_DARK)
        }
        col.addView(keyEt, cp())
        col.addView(btn("Активировать", true) { onActivate() }, cp())
        col.addView(btn("Список номеров", false) { listDialog() }, cp())
        col.addView(btn("Инструкция", false) { showIntro() }, cp())
        col.addView(TextView(this).apply {
            text = "Вернуть мою клавиатуру"; textSize = 12f; setTextColor(Th.MUTED)
            typeface = Th.mono(false); gravity = Gravity.CENTER
            setPadding(0, d(10f), 0, d(10f))
            setOnClickListener {
                Thread { Shell.imeOff(applicationContext) }.start()
                Toast.makeText(this@MainActivity, "Клавиатура возвращена", Toast.LENGTH_SHORT).show()
            }
        }, cp())

        root.addView(ScrollView(this).apply { addView(col) }, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
    }

    private fun showIntro() {
        AlertDialog.Builder(this).setMessage(T.INTRO)
            .setPositiveButton("Закрыть", null).show()
    }

    private fun listDialog() {
        val et = EditText(this).apply {
            setText(U.rawList(this@MainActivity)); setTextColor(Color.BLACK)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 6; gravity = Gravity.TOP
        }
        AlertDialog.Builder(this).setTitle("Список 6-значных номеров")
            .setMessage("Вставьте номера (по одному в строке или через пробел)")
            .setView(et)
            .setPositiveButton("Сохранить") { _, _ ->
                U.saveList(this, et.text.toString())
                Toast.makeText(this, "Номеров: ${U.numbers(this).size}", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("Отмена", null).show()
    }

    private fun onActivate() {
        if (keyEt.text.toString().trim() == U.KEY) proceed(false)
        else Toast.makeText(this, "Неверный ключ", Toast.LENGTH_SHORT).show()
    }

    private fun a11yOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        return s.contains(packageName + "/" + SimAccessibilityService::class.java.name)
    }

    private fun proceed(auto: Boolean) {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Разрешите отображение поверх других окон", Toast.LENGTH_LONG).show()
            if (!auto) {
                prefs.edit().putBoolean("pending", true).apply()
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
            return
        }
        if (!a11yOn()) {
            Toast.makeText(this, "Включите службу SIMFOUND в специальных возможностях", Toast.LENGTH_LONG).show()
            if (!auto) {
                prefs.edit().putBoolean("pending", true).apply()
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 5)
        }
        Shell.requestPermission()
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), 77)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 77) {
            if (res == RESULT_OK && data != null) {
                startForegroundService(Intent(this, FloatingService::class.java)
                    .putExtra("code", res).putExtra("data", data))
                launchGame()
            } else Toast.makeText(this, "Нужно разрешить запись экрана", Toast.LENGTH_LONG).show()
        }
    }

    private fun launchGame() {
        val pm = packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val app = pm.queryIntentActivities(i, 0).firstOrNull {
            val l = it.loadLabel(pm).toString().lowercase()
            l.contains("grand") && l.contains("mobile")
        }
        val launch = app?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
        try {
            if (launch != null) startActivity(launch)
            else startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=Grand%20Mobile&c=apps")))
        } catch (e: Exception) {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/search?q=Grand%20Mobile&c=apps")))
        }
    }
}
